package com.example.dofusfarm

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** Draw estimated visual matches on top of screenshot; does not send taps to any app. */
class ImageOverlayView(context: Context): View(context) {
    var image: Bitmap? = null
        set(value) { field = value; invalidate() }
    var hits: Map<String, ScreenMatcher.Hit> = emptyMap()
        set(value) { field = value; invalidate() }
    var chosen: Pair<Int, Int>? = null
        set(value) { field = value; invalidate() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(159, 94, 252); style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 208, 51); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 26f; isFakeBoldText = true
    }

    private fun screenPoint(x: Int, y: Int): Pair<Float, Float>? {
        val b = image ?: return null
        val s = min(width / b.width.toFloat(), height / b.height.toFloat())
        val dx = (width - b.width * s) / 2f
        val dy = (height - b.height * s) / 2f
        return Pair(dx + x * s, dy + y * s)
    }
    fun imagePoint(vx: Float, vy: Float): Pair<Int, Int>? {
        val b = image ?: return null
        val s = min(width / b.width.toFloat(), height / b.height.toFloat())
        if (s <= 0) return null
        val dx = (width - b.width * s) / 2f
        val dy = (height - b.height * s) / 2f
        val x = ((vx - dx) / s).toInt()
        val y = ((vy - dy) / s).toInt()
        return if (x in 0 until b.width && y in 0 until b.height) x to y else null
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for ((role, hit) in hits) {
            val p = screenPoint(hit.x, hit.y) ?: continue
            canvas.drawCircle(p.first,p.second,28f,ring)
            canvas.drawText(role, p.first + 24f, p.second - 22f, label)
        }
        chosen?.let { point ->
            val p = screenPoint(point.first, point.second) ?: return@let
            canvas.drawCircle(p.first,p.second,20f,cross)
            canvas.drawLine(p.first - 32f,p.second,p.first + 32f,p.second,cross)
            canvas.drawLine(p.first,p.second - 32f,p.first,p.second + 32f,cross)
        }
    }
}
