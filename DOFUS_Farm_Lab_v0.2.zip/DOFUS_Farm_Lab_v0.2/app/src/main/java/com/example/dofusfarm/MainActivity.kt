package com.example.dofusfarm

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.opencv.android.OpenCVLoader
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.Executors

/** v0.2: offline screenshot lab, with an explicit picker. No taps, overlays, or Accessibility. */
class MainActivity : Activity() {
    private val bg = Color.rgb(12, 15, 28)
    private val panel = Color.rgb(24, 28, 46)
    private val muted = Color.rgb(174, 183, 207)
    private val purple = Color.rgb(139, 67, 228)
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("farm_v02", MODE_PRIVATE) }

    private lateinit var selectedRole: Spinner
    private lateinit var overlay: ImageOverlayView
    private lateinit var screenshotView: ImageView
    private lateinit var countText: TextView
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var logText: TextView
    private lateinit var pointText: TextView
    private var screenshot: Bitmap? = null
    private var chosenPoint: Pair<Int, Int>? = null
    private var openCvReady = false
    private var analyzing = false
    private var lastResult: ScreenMatcher.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        openCvReady = try { OpenCVLoader.initLocal() } catch (_: Throwable) { false }

        val outer = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }
        outer.addView(root)
        setContentView(outer)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.app_icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(panel, 16)
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(62), dp(62)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titles.addView(text("DOFUS FARM LAB", 22f, Color.WHITE, true))
        titles.addView(text("v0.2 | مختبر صور المعارك", 14f, muted))
        top.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top)
        gap(root, 14)

        val hero = ImageView(this).apply {
            setImageResource(R.drawable.hero_sram)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(panel, 18)
            clipToOutline = true
            contentDescription = "رسم للشخصية والواجهة المقترحة"
        }
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(178)))
        gap(root, 10)
        val tagline = text("Sram 37  •  Kerlog", 16f, Color.WHITE, true)
        root.addView(tagline)
        root.addView(text("هذه النسخة تحلل الصور التي تختارها فقط، ولا تتحكم باللعبة أو تطلب صلاحية Accessibility.", 13f, muted))
        gap(root, 16)

        section(root, "١. صورة المعركة")
        addButton(root, "📷  اختيار لقطة من الهاتف", true) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            startActivityForResult(intent, IMAGE_PICKER)
        }
        root.addView(text("خذ لقطة شاشة من اللعبة بالطريقة المعتادة، ثم اخترها من المعرض. لا تدخل بيانات حسابك هنا.", 13f, muted))
        gap(root, 8)

        val frame = FrameLayout(this).apply {
            background = rounded(panel, 16)
            clipToOutline = true
        }
        screenshotView = ImageView(this).apply {
            setImageResource(R.drawable.hero_sram)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(panel)
        }
        overlay = ImageOverlayView(this)
        frame.addView(screenshotView, FrameLayout.LayoutParams(-1, -1))
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, LinearLayout.LayoutParams(-1, dp(300)))
        overlay.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                chosenPoint = overlay.imagePoint(event.x, event.y)
                overlay.chosen = chosenPoint
                pointText.text = chosenPoint?.let { "النقطة المختارة: (${it.first}, ${it.second})" }
                    ?: "اضغط داخل الصورة بعد استيرادها"
                true
            } else true
        }
        pointText = text("اختر صورة، ثم اضغط على الوحش أو الزر المطلوب", 13f, muted)
        root.addView(pointText)
        gap(root, 14)

        section(root, "٢. تعليم العناصر")
        root.addView(text("اختر نوع العنصر، ثم اضغط وسطه على صورة اللعبة، وبعدها احفظ القالب. كرّر العملية للعناصر التي تريد اكتشافها.", 13f, muted))
        selectedRole = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, TemplateStore.names)
            setBackgroundColor(Color.rgb(230, 232, 244))
        }
        root.addView(selectedRole, LinearLayout.LayoutParams(-1, dp(50)))
        gap(root, 8)
        addButton(root, "＋  حفظ قالب العنصر المختار", false) {
            val image = screenshot
            val pt = chosenPoint
            if (image == null || pt == null) {
                show("اختر لقطة واضغط على العنصر أولاً")
            } else {
                val role = TemplateStore.roles[selectedRole.selectedItemPosition]
                try {
                    TemplateStore.saveTemplate(this, role, image, pt.first, pt.second)
                    refreshTemplates()
                    appendLog("تم حفظ قالب: ${TemplateStore.names[selectedRole.selectedItemPosition]}")
                    show("تم حفظ القالب بنجاح")
                } catch (ex: Exception) { show("تعذر حفظ القالب: ${ex.message}") }
            }
        }
        countText = text("القوالب: 0 من 6", 13f, muted)
        root.addView(countText)
        gap(root, 14)

        section(root, "٣. فحص الصورة")
        addButton(root, "🔎  تحليل الصورة وتحديد العناصر", true) { analyzeImage() }
        statusText = text(if (openCvReady) "جاهز لتحليل الصور المحلية" else "تعذر تحميل مكتبة OpenCV", 14f, Color.WHITE)
        root.addView(statusText)
        root.addView(text("الحلقات البنفسجية تشير إلى تطابق بصري تقريبي؛ قد توجد أخطاء إذا تغيرت أحجام عناصر اللعبة.", 12f, muted))
        gap(root, 14)

        section(root, "٤. تسجيل أرباحك يدوياً")
        statsText = text("", 16f, Color.WHITE, true)
        root.addView(statsText)
        addButton(root, "💰  تسجيل معركة مكتملة", false) { showAddResult() }
        addButton(root, "🗑  مسح الإحصائيات", false) {
            AlertDialog.Builder(this).setTitle("مسح الإحصائيات؟")
                .setMessage("سيتم حذف عداد المعارك والكاما والسجل، دون مسح القوالب.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("مسح") { _, _ ->
                    prefs.edit().clear().apply()
                    refreshStats()
                    refreshLog()
                }.show()
        }
        gap(root, 14)

        section(root, "سجل العمليات")
        logText = text("لا توجد عمليات بعد", 12f, muted)
        root.addView(logText)
        gap(root, 18)
        root.addView(text("⚠️ لا توجد أتمتة فعلية أو لمس للعبة في v0.2. استخدام Bots في DOFUS Touch قد يعرّض حسابك للحظر. المشروع ليس تابعاً لـ Ankama.", 12f, muted))

        screenshot = TemplateStore.readSnapshot(this)
        if (screenshot != null) showImage(screenshot!!)
        refreshTemplates()
        refreshStats()
        refreshLog()
    }

    @Deprecated("Used for the system document picker without an external AndroidX dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != IMAGE_PICKER || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val image = loadImage(uri) ?: throw IllegalStateException("ملف غير صالح")
            screenshot = image
            chosenPoint = null
            lastResult = null
            showImage(image)
            overlay.chosen = null
            overlay.hits = emptyMap()
            TemplateStore.saveSnapshot(this, image)
            pointText.text = "الصورة جاهزة. اضغط على عنصر لتحديده."
            statusText.text = "صورة: ${image.width} × ${image.height}. جاهز للتحليل."
            appendLog("تم استيراد لقطة شاشة")
        } catch (e: Exception) { show("تعذر فتح الصورة: ${e.message}") }
    }

    private fun loadImage(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 2200) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun showImage(bmp: Bitmap) {
        screenshotView.setImageBitmap(bmp)
        overlay.image = bmp
    }

    private fun analyzeImage() {
        if (analyzing) { show("انتظر انتهاء التحليل"); return }
        val bmp = screenshot ?: run { show("استورد صورة من اللعبة أولاً"); return }
        if (!openCvReady) { show("مكتبة OpenCV غير جاهزة"); return }
        val templates = TemplateStore.roles.mapNotNull { role ->
            TemplateStore.read(this, role)?.let { role to it }
        }.toMap()
        if (templates.isEmpty()) { show("احفظ قالباً واحداً على الأقل أولاً"); return }
        analyzing = true
        statusText.text = "جار تحليل ${templates.size} قالب..."
        worker.execute {
            val result = try { ScreenMatcher.analyze(bmp, templates) } catch (ex: Exception) {
                runOnUiThread { show("فشل التحليل: ${ex.message}") }
                null
            } finally { templates.values.forEach { it.recycle() } }
            runOnUiThread {
                analyzing = false
                if (result == null) { statusText.text = "حدث خطأ في المطابقة"; return@runOnUiThread }
                lastResult = result
                overlay.hits = result.hits
                val best = result.scores.entries.sortedByDescending { it.value }
                val scores = best.joinToString("\n") { (role, score) ->
                    val i = TemplateStore.roles.indexOf(role)
                    "${TemplateStore.names[i]}: ${(score * 100).toInt()}% ${if (result.hits.containsKey(role)) "✓" else ""}"
                }
                statusText.text = "المكتشف: ${result.hits.size}/${templates.size}\n${guess(result.hits)}\n$scores"
                appendLog("تحليل صورة: ${result.hits.size} تطابقات")
            }
        }
    }

    private fun guess(hits: Map<String, ScreenMatcher.Hit>): String {
        return when {
            "victory" in hits -> "احتمال وجود شاشة الانتصار. راجع الغنائم وسجلها يدوياً."
            "spell" in hits && "enemy" in hits -> "احتمال أنك داخل معركة. راجع مدى التعويذة وموقع الهدف."
            "ready" in hits -> "احتمال وجود زر جاهز قبل بدء القتال."
            "monster" in hits -> "احتمال وجود مجموعة وحوش على الخريطة."
            else -> "لم يتحدد وضع اللعبة. راجع القوالب والصورة."
        }
    }

    private fun showAddResult() {
        val field = EditText(this).apply {
            hint = "الكاما المكتسبة (مثال: 350)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("تسجيل معركة")
            .setMessage("أدخل الكاما التي حصلت عليها فعلاً من نتيجة المعركة.")
            .setView(field)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val amount = field.text.toString().toLongOrNull()
                if (amount == null || amount < 0 || amount > 100_000_000) {
                    show("أدخل رقماً صحيحاً بين 0 و100 مليون")
                } else {
                    val battles = prefs.getInt("battles", 0) + 1
                    val kamas = prefs.getLong("kamas", 0L) + amount
                    prefs.edit().putInt("battles", battles).putLong("kamas", kamas).apply()
                    refreshStats()
                    appendLog("معركة #$battles: +$amount كاما")
                }
            }.show()
    }

    private fun refreshTemplates() {
        val present = TemplateStore.roles.mapIndexedNotNull { i, role ->
            if (TemplateStore.has(this, role)) TemplateStore.names[i] else null
        }
        countText.text = "القوالب: ${present.size}/6" + if (present.isNotEmpty()) "\nالمحفوظ: ${present.joinToString("، ")}" else ""
    }
    private fun refreshStats() {
        val battles = prefs.getInt("battles", 0)
        val kamas = prefs.getLong("kamas", 0L)
        val fmt = NumberFormat.getNumberInstance(Locale.US)
        statsText.text = "⚔ المعارك: ${fmt.format(battles)}     💰 الكاما: ${fmt.format(kamas)}"
    }
    private fun appendLog(message: String) {
        val current = prefs.getString("log", "").orEmpty()
        val history = (listOf(message) + current.lineSequence().filter { it.isNotBlank() }.take(14))
            .joinToString("\n")
        prefs.edit().putString("log", history).apply()
        refreshLog()
    }
    private fun refreshLog() { if (::logText.isInitialized) logText.text = prefs.getString("log", "")?.ifBlank { "لا توجد عمليات بعد" } ?: "لا توجد عمليات بعد" }
    private fun show(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun section(root: LinearLayout, heading: String) {
        val t = text(heading, 18f, Color.WHITE, true)
        t.setPadding(0, dp(5), 0, dp(8))
        root.addView(t)
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.RIGHT
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(0, dp(3), 0, dp(7))
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun addButton(root: LinearLayout, caption: String, primary: Boolean, action: () -> Unit) {
        val b = Button(this).apply {
            text = caption
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(if (primary) purple else Color.rgb(47, 53, 77), 12)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) }
        root.addView(b, lp)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }
    private fun gap(root: LinearLayout, value: Int) {
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(value)))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density + .5f).toInt()
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
    companion object { private const val IMAGE_PICKER = 90 }
}
