package com.example.dofusfarm

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/** Local-only visual comparison. Results are estimates, not proof of a real game state. */
object ScreenMatcher {
    data class Hit(val x: Int, val y: Int, val score: Double)
    data class Result(val scores: Map<String, Double>, val hits: Map<String, Hit>)

    fun analyze(frame: Bitmap, templates: Map<String, Bitmap>, threshold: Double = 0.84): Result {
        val scores = linkedMapOf<String, Double>()
        val hits = linkedMapOf<String, Hit>()
        val source = Mat(); val gray = Mat(); val half = Mat()
        try {
            Utils.bitmapToMat(frame, source)
            Imgproc.cvtColor(source, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.resize(gray, half, Size(), 0.5, 0.5, Imgproc.INTER_AREA)
            for ((role, template) in templates) {
                val color = Mat(); val tempGray = Mat(); val small = Mat()
                val matched = Mat(); val mean = MatOfDouble(); val dev = MatOfDouble()
                try {
                    Utils.bitmapToMat(template, color)
                    Imgproc.cvtColor(color, tempGray, Imgproc.COLOR_RGBA2GRAY)
                    Imgproc.resize(tempGray, small, Size(), 0.5, 0.5, Imgproc.INTER_AREA)
                    if (small.width() > half.width() || small.height() > half.height() ||
                        small.width() < 8 || small.height() < 8) {
                        scores[role] = 0.0
                        continue
                    }
                    Core.meanStdDev(small, mean, dev)
                    if (dev.toArray().firstOrNull()?.let { it < 8 } != false) {
                        scores[role] = 0.0
                        continue
                    }
                    Imgproc.matchTemplate(half, small, matched, Imgproc.TM_CCOEFF_NORMED)
                    val m = Core.minMaxLoc(matched)
                    val score = if (m.maxVal.isFinite()) m.maxVal.coerceIn(0.0, 1.0) else 0.0
                    scores[role] = score
                    if (score >= threshold) {
                        val x = (m.maxLoc.x * 2 + template.width / 2.0).toInt()
                        val y = (m.maxLoc.y * 2 + template.height / 2.0).toInt()
                        hits[role] = Hit(x, y, score)
                    }
                } finally {
                    color.release(); tempGray.release(); small.release()
                    matched.release(); mean.release(); dev.release()
                }
            }
        } finally { source.release(); gray.release(); half.release() }
        return Result(scores, hits)
    }
}
