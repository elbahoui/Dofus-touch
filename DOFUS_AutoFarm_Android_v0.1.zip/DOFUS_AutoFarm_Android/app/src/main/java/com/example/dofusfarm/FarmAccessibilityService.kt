package com.example.dofusfarm

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import org.opencv.android.OpenCVLoader
import java.util.concurrent.Executors

class FarmAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var active: FarmAccessibilityService? = null
            private set
        private const val TAG = "DOFUS_FARM"
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val engine = FarmEngine()
    private var running = false
    private var busy = false
    private var opencvOk = false
    private var templates: Map<String, Bitmap> = emptyMap()
    private var wm: WindowManager? = null
    private var stopBubble: View? = null
    private var startAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        active = this
        opencvOk = try { OpenCVLoader.initLocal() } catch (ex: Throwable) {
            Log.e(TAG, "OpenCV could not be initialized", ex); false
        }
        status(if (opencvOk) "الخدمة مفعّلة - يمكنك معايرة الصور" else "تعذر تشغيل OpenCV")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopFarm("توقفت خدمة Accessibility") }

    fun scheduleSnapshot() {
        status("افتح اللعبة الآن؛ التقاط الصورة بعد 5 ثوانٍ")
        main.postDelayed({
            takeFrame({ frame ->
                try {
                    TemplateStore.saveSnapshot(this, frame)
                    val pkg = rootInActiveWindow?.packageName?.toString().orEmpty()
                    // Auto-detect the current game window, not the app's own window.
                    if (pkg.isNotEmpty() && pkg != packageName && pkg != "com.android.systemui") {
                        getSharedPreferences("farm", MODE_PRIVATE).edit().putString("game_pkg", pkg).apply()
                    }
                    status("تم حفظ الصورة ${frame.width}×${frame.height}. عد إلى التطبيق وحدد الهدف")
                } finally { frame.recycle() }
            }, { code -> status("فشل التقاط الشاشة (code $code). راجع صلاحية الخدمة") })
        }, 5000)
    }

    fun startFarm() {
        if (running) { status("الفارم يعمل بالفعل"); return }
        if (!opencvOk) { status("OpenCV غير جاهز"); return }
        if (!TemplateStore.ready(this)) { status("يجب حفظ الصور الست أولاً"); return }
        val pkg = getSharedPreferences("farm", MODE_PRIVATE).getString("game_pkg", "").orEmpty()
        if (pkg.isBlank()) { status("افتح اللعبة والتقط صورة أولاً للتعرف على حزمة اللعبة"); return }
        templates.values.forEach { if (!it.isRecycled) it.recycle() }
        templates = TemplateStore.roles.mapNotNull { role ->
            TemplateStore.read(this, role)?.let { role to it }
        }.toMap()
        if (templates.size != 6) { status("بعض القوالب لم تُقرأ"); return }
        engine.reset()
        busy = false
        running = true
        startAt = SystemClock.elapsedRealtime()
        status("سيبدأ الفحص بعد 6 ثوانٍ: افتح اللعبة $pkg")
        showStopBubble()
        main.postDelayed({ if (running) tick() }, 6000)
    }

    fun stopFarm(reason: String = "تم الإيقاف") {
        running = false
        busy = false
        removeStopBubble()
        status(reason + " | معارك: ${engine.battles}")
    }

    private fun tick() {
        if (!running || busy) return
        if (SystemClock.elapsedRealtime() - startAt > 20 * 60 * 1000L) {
            stopFarm("حد التشغيل التجريبي: 20 دقيقة"); return
        }
        val expected = getSharedPreferences("farm", MODE_PRIVATE).getString("game_pkg", "").orEmpty()
        val pkg = rootInActiveWindow?.packageName?.toString()
        // Never send a gesture into an unknown application.
        if (pkg != expected) {
            status("إيقاف مؤقت: اللعبة ليست في الواجهة ($pkg)")
            main.postDelayed({ tick() }, 2000)
            return
        }
        busy = true
        takeFrame({ frame ->
            worker.execute {
                try {
                    val hits = ScreenMatcher.scan(frame, templates)
                    main.post {
                        frame.recycle()
                        if (!running) { busy = false; return@post }
                        val action = engine.next(hits)
                        if (engine.error != null) {
                            stopFarm(engine.error ?: "خطأ في المعركة")
                        } else if (action != null) {
                            val allowTap = getSharedPreferences("farm", MODE_PRIVATE).getBoolean("enable_taps", false)
                            status("${action.description} | وجد: ${hits.keys.joinToString()} | فوز: ${engine.battles}")
                            if (!allowTap) {
                                stopFarm("وضع اختبار: ${action.description} عند ${action.points.first()}")
                            } else {
                                playGestureSequence(action.points) {
                                    busy = false
                                    if (running) main.postDelayed({ tick() }, 1500)
                                }
                            }
                        } else {
                            status("فحص ${engine.state.name} | عناصر: ${hits.keys.joinToString()} | فوز: ${engine.battles}")
                            busy = false
                            main.postDelayed({ tick() }, 1400)
                        }
                    }
                } catch (ex: Throwable) {
                    Log.e(TAG, "Detection error", ex)
                    frame.recycle()
                    main.post { stopFarm("خطأ في مطابقة الصور: ${ex.javaClass.simpleName}") }
                }
            }
        }, { code ->
            busy = false
            if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                main.postDelayed({ tick() }, 1800)
            } else {
                stopFarm("تعذر تصوير اللعبة ($code)")
            }
        })
    }

    private fun playGestureSequence(points: List<Pair<Int, Int>>, onDone: () -> Unit) {
        if (!running || points.isEmpty()) { onDone(); return }
        val expected = getSharedPreferences("farm", MODE_PRIVATE).getString("game_pkg", "")
        if (rootInActiveWindow?.packageName?.toString() != expected) {
            stopFarm("توقفت اللمسات: خرجت من اللعبة"); onDone(); return
        }
        val point = points.first()
        val path = Path().apply { moveTo(point.first.toFloat(), point.second.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 90)
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                main.postDelayed({ playGestureSequence(points.drop(1), onDone) }, 550)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                stopFarm("Android رفض إحدى اللمسات"); onDone()
            }
        }, main)
        if (!accepted) { stopFarm("لم تُقبل اللمسة"); onDone() }
    }

    private fun takeFrame(onFrame: (Bitmap) -> Unit, onError: (Int) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val buffer = screenshot.hardwareBuffer
                try {
                    val hardwareBmp = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                    if (hardwareBmp == null) { onError(-1); return }
                    val mutableCopy = hardwareBmp.copy(Bitmap.Config.ARGB_8888, false)
                    if (mutableCopy == null) onError(-2) else onFrame(mutableCopy)
                } catch (ex: Throwable) {
                    Log.e(TAG, "Screenshot conversion error", ex)
                    onError(-3)
                } finally { buffer.close() }
            }
            override fun onFailure(errorCode: Int) { onError(errorCode) }
        })
    }

    private fun showStopBubble() {
        if (stopBubble != null) return
        val label = TextView(this).apply {
            text = "■ STOP FARM"
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(150, 32, 38))
            setPadding(22, 14, 22, 14)
            setOnClickListener { stopFarm("إيقاف يدوي") }
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 15; y = 95 }
        try {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            wm?.addView(label, p)
            stopBubble = label
        } catch (ex: Throwable) { status("تعذر إظهار زر الإيقاف: ${ex.message}") }
    }

    private fun removeStopBubble() {
        stopBubble?.let { try { wm?.removeView(it) } catch (_: Throwable) {} }
        stopBubble = null
    }

    private fun status(value: String) {
        Log.i(TAG, value)
        getSharedPreferences("farm", MODE_PRIVATE).edit()
            .putString("status", value).putInt("battles", engine.battles).apply()
    }

    override fun onDestroy() {
        stopFarm("خدمة Accessibility مغلقة")
        templates.values.forEach { if (!it.isRecycled) it.recycle() }
        worker.shutdownNow()
        if (active === this) active = null
        super.onDestroy()
    }
}
