package com.example.dofusfarm

import android.graphics.Bitmap
import android.util.Log
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/** Visual matching is approximate. Stable UI screenshots and calibration are essential. */
object ScreenMatcher {
    data class Hit(val x: Int, val y: Int, val score: Double)

    // No account data. All matching happens locally on the phone.
    fun scan(frame: Bitmap, templates: Map<String, Bitmap>, threshold: Double = 0.87): Map<String, Hit> {
        val result = mutableMapOf<String, Hit>()
        val rgba = Mat()
        val gray = Mat()
        val reduced = Mat()
        try {
            Utils.bitmapToMat(frame, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.resize(gray, reduced, Size(), 0.5, 0.5, Imgproc.INTER_AREA)

            for ((role, bitmap) in templates) {
                val trgba = Mat()
                val tgray = Mat()
                val tsmall = Mat()
                val comparisons = Mat()
                val mean = MatOfDouble()
                val std = MatOfDouble()
                try {
                    Utils.bitmapToMat(bitmap, trgba)
                    Imgproc.cvtColor(trgba, tgray, Imgproc.COLOR_RGBA2GRAY)
                    Imgproc.resize(tgray, tsmall, Size(), 0.5, 0.5, Imgproc.INTER_AREA)
                    if (tsmall.cols() > reduced.cols() || tsmall.rows() > reduced.rows() ||
                        tsmall.cols() < 8 || tsmall.rows() < 8) continue
                    Core.meanStdDev(tsmall, mean, std)
                    // Reject nearly solid color patches that match almost everywhere.
                    if (std.toArray().firstOrNull()?.let { it < 7.0 } != false) continue
                    Imgproc.matchTemplate(reduced, tsmall, comparisons, Imgproc.TM_CCOEFF_NORMED)
                    val mm = Core.minMaxLoc(comparisons)
                    Log.d("DOFUS_FARM", "$role score=${mm.maxVal}")
                    if (mm.maxVal >= threshold) {
                        val x = (mm.maxLoc.x * 2.0 + bitmap.width / 2.0).toInt()
                        val y = (mm.maxLoc.y * 2.0 + bitmap.height / 2.0).toInt()
                        result[role] = Hit(x, y, mm.maxVal)
                    }
                } finally {
                    trgba.release(); tgray.release(); tsmall.release(); comparisons.release()
                    mean.release(); std.release()
                }
            }
        } finally {
            rgba.release(); gray.release(); reduced.release()
        }
        return result
    }
}
