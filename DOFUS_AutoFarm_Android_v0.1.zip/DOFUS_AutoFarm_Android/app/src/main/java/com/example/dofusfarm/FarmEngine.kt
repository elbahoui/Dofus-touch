package com.example.dofusfarm

import android.os.SystemClock

/** Small deterministic state machine. Does not claim to play every combat strategy. */
class FarmEngine {
    enum class State { SEEK, READY, FIGHT, RESULT }
    data class Instruction(val points: List<Pair<Int, Int>>, val description: String)

    var state = State.SEEK
        private set
    var battles = 0
        private set
    var turns = 0
        private set
    var lastActionAt = 0L
        private set
    private var enteredAt = SystemClock.elapsedRealtime()
    var error: String? = null
        private set

    fun reset() {
        state = State.SEEK
        battles = 0
        turns = 0
        error = null
        lastActionAt = 0L
        enteredAt = SystemClock.elapsedRealtime()
    }

    fun next(hits: Map<String, ScreenMatcher.Hit>): Instruction? {
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < 2700L) return null
        if (now - enteredAt > when (state) {
                State.SEEK -> 120000L
                State.READY -> 45000L
                State.FIGHT -> 120000L
                State.RESULT -> 30000L
            }) {
            error = "انتهت مهلة ${state.name}: توقف آمن، أعد معايرة الصور"
            return null
        }
        fun center(role: String) = hits.getValue(role).let { it.x to it.y }
        fun change(next: State) { state = next; enteredAt = now }

        return when (state) {
            State.SEEK -> {
                if ("monster" in hits) {
                    change(State.READY)
                    lastActionAt = now
                    Instruction(listOf(center("monster")), "بدء قتال الوحش")
                } else null
            }
            State.READY -> {
                if ("ready" in hits) {
                    change(State.FIGHT)
                    lastActionAt = now
                    Instruction(listOf(center("ready")), "ضغط جاهز")
                } else if ("spell" in hits && "endturn" in hits) {
                    change(State.FIGHT)
                    null
                } else null
            }
            State.FIGHT -> {
                if ("victory" in hits) {
                    battles++
                    change(State.RESULT)
                    lastActionAt = now
                    Instruction(listOf(center("victory")), "فوز رقم $battles - إغلاق النتيجة")
                } else if ("spell" in hits && "enemy" in hits && "endturn" in hits) {
                    turns++
                    if (turns > 16) {
                        error = "تجاوز 16 دوراً دون فوز، تم الإيقاف"
                        null
                    } else {
                        lastActionAt = now
                        Instruction(listOf(center("spell"), center("enemy"), center("endturn")), "دور قتال $turns")
                    }
                } else null
            }
            State.RESULT -> {
                if (now - enteredAt > 2200L && "victory" !in hits) {
                    turns = 0
                    change(State.SEEK)
                }
                null
            }
        }
    }
}
