package com.example.dofusfarm

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var templatesText: TextView
    private lateinit var screenshot: ImageView
    private lateinit var roles: Spinner
    private lateinit var allowTouches: CheckBox
    private var screenshotBmp: Bitmap? = null
    private val prefs by lazy { getSharedPreferences("farm", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(22))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = ScrollView(this).apply { addView(root) }
        setContentView(scroller)

        header(root, "DOFUS FARM LAB", 25f)
        paragraph(root, "نسخة تجريبية 0.1 | تعمل محلياً بدون Root أو اشتراك. تحتاج Android 11+ وخدمة Accessibility.")
        header(root, "1. التفعيل", 20f)
        button(root, "فتح إعدادات Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        statusText = paragraph(root, "حالة الخدمة: ...")

        header(root, "2. الصور المرجعية", 20f)
        paragraph(root, "افتح شاشة مناسبة في اللعبة ثم عد لهذا التطبيق، واضغط التقاط، وانتقل فوراً للعبة. بعد 5 ثوانٍ ستُحفظ صورة شاشة اللعبة. ارجع هنا واضغط على الشيء المراد تعليمه.")
        button(root, "📸 التقاط صورة بعد 5 ثوانٍ") {
            val service = FarmAccessibilityService.active
            if (service == null) alert("فعّل Accessibility أولاً") else {
                service.scheduleSnapshot()
                Toast.makeText(this, "انتقل الآن إلى DOFUS Touch", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        }

        roles = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item, TemplateStore.names)
        }
        root.addView(roles, LinearLayout.LayoutParams(-1, dp(56)))
        templatesText = paragraph(root, "0 / 6 صور محفوظة")
        screenshot = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(android.graphics.Color.rgb(232, 236, 240))
            adjustViewBounds = false
        }
        root.addView(screenshot, LinearLayout.LayoutParams(-1, dp(260)))
        screenshot.setOnTouchListener { _, event ->
            if (event.action != MotionEvent.ACTION_UP) return@setOnTouchListener true
            val bmp = screenshotBmp ?: run { alert("التقط صورة أولاً"); return@setOnTouchListener true }
            val inverse = Matrix()
            if (!screenshot.imageMatrix.invert(inverse)) return@setOnTouchListener true
            val point = floatArrayOf(event.x, event.y)
            inverse.mapPoints(point)
            val x = point[0].toInt()
            val y = point[1].toInt()
            if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) {
                alert("اضغط داخل صورة اللعبة")
            } else {
                val id = TemplateStore.roles[roles.selectedItemPosition]
                try {
                    TemplateStore.saveTemplate(this, id, bmp, x, y)
                    alert("تم حفظ: ${TemplateStore.names[roles.selectedItemPosition]}")
                    updateView()
                } catch (e: Exception) {
                    alert("تعذر الحفظ: ${e.message}")
                }
            }
            true
        }
        button(root, "تحديث الصورة والحالة") { updateView() }

        header(root, "3. التجربة", 20f)
        paragraph(root, "اختر 6 صور: وحش في الخريطة، زر جاهز، تعويذة Sram، عدو أثناء القتال، إنهاء الدور، ثم شاشة الفوز. للعنصر المتحرك قد تفشل المطابقة. اختبر أولاً دون لمس.")
        allowTouches = CheckBox(this).apply {
            text = "السماح باللمسات التلقائية (بعد نجاح الاختبار)"
            isChecked = prefs.getBoolean("enable_taps", false)
            setOnCheckedChangeListener { _, enabled ->
                prefs.edit().putBoolean("enable_taps", enabled).apply()
            }
        }
        root.addView(allowTouches)
        button(root, "▶ START FARM") {
            val svc = FarmAccessibilityService.active
            if (svc == null) alert("فعّل خدمة Accessibility")
            else if (!TemplateStore.ready(this)) alert("تحتاج إلى معايرة الصور الست قبل التشغيل")
            else {
                svc.startFarm()
                alert("انتقل إلى اللعبة. سيبدأ الفحص بعد 6 ثوانٍ")
                moveTaskToBack(true)
            }
        }
        button(root, "■ STOP FARM") {
            FarmAccessibilityService.active?.stopFarm("إيقاف من لوحة التحكم")
            updateView()
        }
        paragraph(root, "⚠️ تجريبي: هجوم واحد فقط لكل دور، دون مسار حركة أو بيع أو قراءة تلقائية للكاما. استخدام البوتات قد يؤدي إلى حظر الحساب وفق قواعد Ankama. لا تدخل كلمة مرور اللعبة في هذا التطبيق.")
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) updateView()
    }

    private fun updateView() {
        val serviceState = if (FarmAccessibilityService.active != null) "مفعّلة" else "غير مفعّلة"
        val pkg = prefs.getString("game_pkg", "لم يحدد بعد")
        statusText.text = "الخدمة: $serviceState\nلعبة: $pkg\nالحالة: ${prefs.getString("status", "بانتظار التفعيل")}\nالمعارك المعلنة: ${prefs.getInt("battles", 0)}"
        templatesText.text = "الصور: ${TemplateStore.presentCount(this)}/6 | " +
            TemplateStore.roles.mapIndexed { index, role ->
                "${if (TemplateStore.has(this, role)) "✓" else "×"} ${TemplateStore.names[index]}"
            }.joinToString("، ")
        screenshotBmp?.recycle()
        screenshotBmp = TemplateStore.readSnapshot(this)
        screenshot.setImageBitmap(screenshotBmp)
    }

    private fun header(root: LinearLayout, text: String, size: Float): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(android.graphics.Color.rgb(25, 39, 62))
            setPadding(0, dp(12), 0, dp(8))
            root.addView(this)
        }
    }

    private fun paragraph(root: LinearLayout, text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(android.graphics.Color.rgb(75, 82, 92))
            setPadding(0, dp(5), 0, dp(12))
            root.addView(this)
        }
    }

    private fun button(root: LinearLayout, title: String, onClick: () -> Unit) {
        Button(this).apply {
            text = title
            isAllCaps = false
            setOnClickListener { onClick() }
            root.addView(this, LinearLayout.LayoutParams(-1, dp(52)))
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun alert(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        screenshot.setImageDrawable(null)
        screenshotBmp?.recycle()
        screenshotBmp = null
        super.onDestroy()
    }
}
