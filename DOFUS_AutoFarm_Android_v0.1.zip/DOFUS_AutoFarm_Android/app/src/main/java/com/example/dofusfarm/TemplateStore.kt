package com.example.dofusfarm

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

/** Local-only images; no network calls or account credentials. */
object TemplateStore {
    val roles = listOf("monster", "ready", "spell", "enemy", "endturn", "victory")
    val names = listOf("وحش على الخريطة", "زر جاهز", "تعويذة Sram", "هدف داخل القتال", "إنهاء الدور", "نتيجة الانتصار")

    private fun file(context: Context, role: String) = File(context.filesDir, "tpl_$role.png")
    private fun snapshotFile(context: Context) = File(context.filesDir, "snapshot.png")

    fun has(context: Context, role: String) = file(context, role).exists()
    fun presentCount(context: Context) = roles.count { has(context, it) }
    fun ready(context: Context) = presentCount(context) == roles.size

    fun read(context: Context, role: String): Bitmap? {
        val f = file(context, role)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    fun readSnapshot(context: Context): Bitmap? {
        val f = snapshotFile(context)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    fun saveSnapshot(context: Context, bmp: Bitmap) {
        saveBitmap(snapshotFile(context), bmp)
    }

    fun saveTemplate(context: Context, role: String, bmp: Bitmap, centerX: Int, centerY: Int) {
        require(role in roles)
        val half = when (role) {
            "monster", "enemy" -> 48
            "victory" -> 56
            else -> 36
        }
        val left = (centerX - half).coerceIn(0, (bmp.width - 1).coerceAtLeast(0))
        val top = (centerY - half).coerceIn(0, (bmp.height - 1).coerceAtLeast(0))
        val w = (half * 2).coerceAtMost(bmp.width - left)
        val h = (half * 2).coerceAtMost(bmp.height - top)
        require(w >= 20 && h >= 20) { "اختر نقطة بعيدة عن أطراف الصورة" }
        val crop = Bitmap.createBitmap(bmp, left, top, w, h)
        saveBitmap(file(context, role), crop)
        crop.recycle()
    }

    private fun saveBitmap(f: File, bmp: Bitmap) {
        FileOutputStream(f).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
    }
}
